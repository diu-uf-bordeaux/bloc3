//
// SimcirJS - Added library
//

// includes following device types:
//  BlinNot



//simcir.registerDevice('D-FF-E-R',
//{
//  "width":360,
//  "height":440,
//  "showToolbox":false,
//  "toolbox":[
//  ],
//     "devices":[
//    {"type":"D-FF","id":"dev0","x":272,"y":232,"label":"D-FF"},
//    {"type":"In","id":"dev1","x":96,"y":224,"label":"R"},
//    {"type":"NOT","id":"dev2","x":160,"y":224,"label":"NOT"},
//    {"type":"In","id":"dev3","x":96,"y":280,"label":"E"},
//    {"type":"In","id":"dev4","x":96,"y":336,"label":"CLK"},
//    {"type":"AND","id":"dev5","x":216,"y":176,"label":"AND"},
//    {"type":"AND","id":"dev6","x":208,"y":328,"label":"AND"},
//    {"type":"Out","id":"dev7","x":368,"y":200,"label":"Q"},
//    {"type":"Out","id":"dev8","x":368,"y":264,"label":"~Q"},
//    {"type":"Toggle","id":"dev9","x":48,"y":280,"label":"Toggle"},
//    {"type":"Toggle","id":"dev10","x":56,"y":168,"label":"Toggle"},
//    {"type":"Toggle","id":"dev11","x":48,"y":224,"label":"Toggle"},
//    {"type":"LED","id":"dev12","x":464,"y":176,"label":"LED"},
//    {"type":"In","id":"dev13","x":144,"y":168,"label":"D"},
//    {"type":"DC","id":"dev14","x":0,"y":192,"label":"DC"},
//    {"type":"OSC","id":"dev15","x":24,"y":344,"label":"OSC"}
//  ],
//  "connectors":[
//    {"from":"dev0.in0","to":"dev5.out0"},
//    {"from":"dev0.in1","to":"dev6.out0"},
//    {"from":"dev1.in0","to":"dev11.out0"},
//    {"from":"dev2.in0","to":"dev1.out0"},
//    {"from":"dev3.in0","to":"dev9.out0"},
//    {"from":"dev4.in0","to":"dev15.out0"},
//    {"from":"dev5.in0","to":"dev13.out0"},
//    {"from":"dev5.in1","to":"dev2.out0"},
//    {"from":"dev6.in0","to":"dev3.out0"},
//    {"from":"dev6.in1","to":"dev4.out0"},
//    {"from":"dev7.in0","to":"dev0.out0"},
//    {"from":"dev8.in0","to":"dev0.out1"},
//    {"from":"dev9.in0","to":"dev14.out0"},
//    {"from":"dev10.in0","to":"dev14.out0"},
//    {"from":"dev11.in0","to":"dev14.out0"},
//    {"from":"dev12.in0","to":"dev7.out0"},
//    {"from":"dev13.in0","to":"dev10.out0"}
//  ]
//}
//);

//
// Décodeurs/encodeurs
//

simcir.registerDevice('2to4DecoderBus',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"In","id":"dev0","x":40,"y":392,"label":"D"},
    {"type":"Out","id":"dev1","x":360,"y":304,"label":"A0"},
    {"type":"Out","id":"dev2","x":360,"y":368,"label":"A1"},
    {"type":"Out","id":"dev3","x":360,"y":432,"label":"A2"},
    {"type":"2to4Decoder","id":"dev4","x":224,"y":384,"label":"2to4Decoder"},
    {"type":"BusIn","id":"dev5","x":136,"y":392,"label":"BusIn","numOutputs":2},
    {"type":"Out","id":"dev6","x":360,"y":496,"label":"A3"},
    {"type":"DC","id":"dev7","x":160,"y":472,"label":"DC"}
  ],
  "connectors":[
    {"from":"dev1.in0","to":"dev4.out0"},
    {"from":"dev2.in0","to":"dev4.out1"},
    {"from":"dev3.in0","to":"dev4.out2"},
    {"from":"dev4.in0","to":"dev5.out0"},
    {"from":"dev4.in1","to":"dev5.out1"},
    {"from":"dev4.in2","to":"dev7.out0"},
    {"from":"dev5.in0","to":"dev0.out0"},
    {"from":"dev6.in0","to":"dev4.out3"}
  ]
}
);

simcir.registerDevice('4to2PrioEncoder',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"In","id":"dev0","x":216,"y":368,"label":"D1"},
    {"type":"In","id":"dev1","x":216,"y":424,"label":"D2"},
    {"type":"In","id":"dev2","x":216,"y":480,"label":"D3"},
    {"type":"In","id":"dev3","x":216,"y":312,"label":"D0"},
    {"type":"RotaryEncoder","id":"dev4","x":96,"y":376,"label":"RotaryEncoder"},
    {"type":"DC","id":"dev5","x":40,"y":392,"label":"DC"},
    {"type":"Out","id":"dev6","x":624,"y":352,"label":"S0"},
    {"type":"Out","id":"dev7","x":624,"y":432,"label":"S1"},
    {"type":"OR","id":"dev8","x":304,"y":440,"label":"OR"},
    {"type":"NOT","id":"dev9","x":376,"y":400,"label":"NOT"},
    {"type":"AND","id":"dev10","x":448,"y":368,"label":"AND"},
    {"type":"OR","id":"dev11","x":528,"y":360,"label":"OR"},
    {"type":"4bit7seg","id":"dev12","x":712,"y":392,"label":"4bit7seg"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev4.out1"},
    {"from":"dev1.in0","to":"dev4.out2"},
    {"from":"dev2.in0","to":"dev4.out3"},
    {"from":"dev3.in0","to":"dev4.out0"},
    {"from":"dev4.in0","to":"dev5.out0"},
    {"from":"dev6.in0","to":"dev11.out0"},
    {"from":"dev7.in0","to":"dev8.out0"},
    {"from":"dev8.in0","to":"dev1.out0"},
    {"from":"dev8.in1","to":"dev2.out0"},
    {"from":"dev9.in0","to":"dev8.out0"},
    {"from":"dev10.in0","to":"dev0.out0"},
    {"from":"dev10.in1","to":"dev9.out0"},
    {"from":"dev11.in0","to":"dev10.out0"},
    {"from":"dev11.in1","to":"dev2.out0"},
    {"from":"dev12.in0","to":"dev6.out0"},
    {"from":"dev12.in1","to":"dev7.out0"}
  ]
}
);

//
// Multiplexeurs/démultiplexeurs
//

simcir.registerDevice('Mux',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"In","id":"dev0","x":136,"y":400,"label":"D1"},
    {"type":"2to4Decoder","id":"dev1","x":248,"y":176,"label":"2to4Decoder"},
    {"type":"In","id":"dev2","x":120,"y":192,"label":"Sel"},
    {"type":"BusIn","id":"dev3","x":184,"y":192,"label":"BusIn","numOutputs":2},
    {"type":"In","id":"dev4","x":136,"y":472,"label":"D2"},
    {"type":"In","id":"dev5","x":136,"y":544,"label":"D3"},
    {"type":"AND","id":"dev6","x":336,"y":328,"label":"AND"},
    {"type":"AND","id":"dev7","x":336,"y":472,"label":"AND"},
    {"type":"AND","id":"dev8","x":336,"y":544,"label":"AND"},
    {"type":"In","id":"dev9","x":136,"y":328,"label":"D0"},
    {"type":"DC","id":"dev10","x":184,"y":264,"label":"DC"},
    {"type":"AND","id":"dev11","x":336,"y":400,"label":"AND"},
    {"type":"OR","numInputs":4,"id":"dev12","x":456,"y":424,"label":"OR"},
    {"type":"Out","id":"dev13","x":536,"y":424,"label":"S"}
  ],
  "connectors":[
    {"from":"dev1.in0","to":"dev3.out0"},
    {"from":"dev1.in1","to":"dev3.out1"},
    {"from":"dev1.in2","to":"dev10.out0"},
    {"from":"dev3.in0","to":"dev2.out0"},
    {"from":"dev6.in0","to":"dev1.out0"},
    {"from":"dev6.in1","to":"dev9.out0"},
    {"from":"dev7.in0","to":"dev1.out2"},
    {"from":"dev7.in1","to":"dev4.out0"},
    {"from":"dev8.in0","to":"dev1.out3"},
    {"from":"dev8.in1","to":"dev5.out0"},
    {"from":"dev11.in0","to":"dev1.out1"},
    {"from":"dev11.in1","to":"dev0.out0"},
    {"from":"dev12.in0","to":"dev6.out0"},
    {"from":"dev12.in1","to":"dev11.out0"},
    {"from":"dev12.in2","to":"dev7.out0"},
    {"from":"dev12.in3","to":"dev8.out0"},
    {"from":"dev13.in0","to":"dev12.out0"}
  ]
}
);

simcir.registerDevice('Mux2',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"In","id":"dev0","x":208,"y":168,"label":"Sel"},
    {"type":"NOT","id":"dev1","x":264,"y":168,"label":"NOT"},
    {"type":"AND","id":"dev2","x":336,"y":256,"label":"AND"},
    {"type":"Out","id":"dev3","x":496,"y":304,"label":"S"},
    {"type":"OR","id":"dev4","x":424,"y":304,"label":"OR"},
    {"type":"In","id":"dev5","x":208,"y":264,"label":"D0"},
    {"type":"In","id":"dev6","x":208,"y":344,"label":"D1"},
    {"type":"AND","id":"dev7","x":336,"y":336,"label":"AND"},
    {"type":"Toggle","id":"dev8","x":152,"y":168,"label":"Toggle"},
    {"type":"DC","id":"dev9","x":72,"y":264,"label":"DC"},
    {"type":"Toggle","id":"dev10","x":152,"y":264,"label":"Toggle"},
    {"type":"Toggle","id":"dev11","x":152,"y":344,"label":"Toggle"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev8.out0"},
    {"from":"dev1.in0","to":"dev0.out0"},
    {"from":"dev2.in0","to":"dev1.out0"},
    {"from":"dev2.in1","to":"dev5.out0"},
    {"from":"dev3.in0","to":"dev4.out0"},
    {"from":"dev4.in0","to":"dev2.out0"},
    {"from":"dev4.in1","to":"dev7.out0"},
    {"from":"dev5.in0","to":"dev10.out0"},
    {"from":"dev6.in0","to":"dev11.out0"},
    {"from":"dev7.in0","to":"dev0.out0"},
    {"from":"dev7.in1","to":"dev6.out0"},
    {"from":"dev8.in0","to":"dev9.out0"},
    {"from":"dev10.in0","to":"dev9.out0"},
    {"from":"dev11.in0","to":"dev9.out0"}
  ]
}
);

simcir.registerDevice('MuxBus',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"In","id":"dev0","x":136,"y":328,"label":"D0"},
    {"type":"In","id":"dev1","x":136,"y":400,"label":"D1"},
    {"type":"2to4Decoder","id":"dev2","x":248,"y":176,"label":"2to4Decoder"},
    {"type":"In","id":"dev3","x":120,"y":192,"label":"Sel"},
    {"type":"BusIn","id":"dev4","x":184,"y":192,"label":"BusIn","numOutputs":2},
    {"type":"AndBus1","id":"dev5","x":352,"y":336,"label":"AndBus1"},
    {"type":"AndBus1","id":"dev6","x":352,"y":408,"label":"AndBus1"},
    {"type":"AndBus1","id":"dev7","x":352,"y":552,"label":"AndBus1"},
    {"type":"AndBus1","id":"dev8","x":352,"y":480,"label":"AndBus1"},
    {"type":"In","id":"dev9","x":136,"y":472,"label":"D2"},
    {"type":"In","id":"dev10","x":136,"y":544,"label":"D3"},
    {"type":"OrBus","id":"dev11","x":480,"y":376,"label":"OrBus"},
    {"type":"OrBus","id":"dev12","x":480,"y":512,"label":"OrBus"},
    {"type":"OrBus","id":"dev13","x":584,"y":440,"label":"OrBus"},
    {"type":"Out","id":"dev14","x":680,"y":440,"label":"S"},
    {"type":"DC","id":"dev15","x":192,"y":280,"label":"DC"}
  ],
  "connectors":[
    {"from":"dev2.in0","to":"dev4.out0"},
    {"from":"dev2.in1","to":"dev4.out1"},
    {"from":"dev2.in2","to":"dev15.out0"},
    {"from":"dev4.in0","to":"dev3.out0"},
    {"from":"dev5.in0","to":"dev0.out0"},
    {"from":"dev5.in1","to":"dev2.out0"},
    {"from":"dev6.in0","to":"dev1.out0"},
    {"from":"dev6.in1","to":"dev2.out1"},
    {"from":"dev7.in0","to":"dev10.out0"},
    {"from":"dev7.in1","to":"dev2.out3"},
    {"from":"dev8.in0","to":"dev9.out0"},
    {"from":"dev8.in1","to":"dev2.out2"},
    {"from":"dev11.in0","to":"dev5.out0"},
    {"from":"dev11.in1","to":"dev6.out0"},
    {"from":"dev12.in0","to":"dev8.out0"},
    {"from":"dev12.in1","to":"dev7.out0"},
    {"from":"dev13.in0","to":"dev11.out0"},
    {"from":"dev13.in1","to":"dev12.out0"},
    {"from":"dev14.in0","to":"dev13.out0"}
  ]
}
);

simcir.registerDevice('MuxBus2',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"AndBus1","id":"dev0","x":352,"y":216,"label":"AndBus1"},
    {"type":"OrBus","id":"dev1","x":480,"y":248,"label":"OrBus"},
    {"type":"Out","id":"dev2","x":592,"y":248,"label":"S"},
    {"type":"AndBus1","id":"dev3","x":352,"y":288,"label":"AndBus1"},
    {"type":"In","id":"dev4","x":208,"y":96,"label":"Sel"},
    {"type":"In","id":"dev5","x":208,"y":208,"label":"D0"},
    {"type":"In","id":"dev6","x":208,"y":288,"label":"D1"},
    {"type":"NOT","id":"dev7","x":288,"y":96,"label":"NOT"},
    {"type":"4bit7segBus","id":"dev8","x":664,"y":232,"label":"4bit7segBus"},
    {"type":"RotaryEncoderBus","id":"dev9","x":104,"y":192,"label":"RotaryEncoderBus"},
    {"type":"RotaryEncoderBus","id":"dev10","x":104,"y":272,"label":"RotaryEncoderBus"},
    {"type":"DC","id":"dev11","x":16,"y":208,"label":"DC"},
    {"type":"Toggle","id":"dev12","x":104,"y":96,"label":"Toggle"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev5.out0"},
    {"from":"dev0.in1","to":"dev7.out0"},
    {"from":"dev1.in0","to":"dev0.out0"},
    {"from":"dev1.in1","to":"dev3.out0"},
    {"from":"dev2.in0","to":"dev1.out0"},
    {"from":"dev3.in0","to":"dev6.out0"},
    {"from":"dev3.in1","to":"dev4.out0"},
    {"from":"dev4.in0","to":"dev12.out0"},
    {"from":"dev5.in0","to":"dev9.out0"},
    {"from":"dev6.in0","to":"dev10.out0"},
    {"from":"dev7.in0","to":"dev4.out0"},
    {"from":"dev8.in0","to":"dev2.out0"},
    {"from":"dev9.in0","to":"dev11.out0"},
    {"from":"dev10.in0","to":"dev11.out0"},
    {"from":"dev12.in0","to":"dev11.out0"}
  ]
}
);

simcir.registerDevice('Demux',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"2to4Decoder","id":"dev0","x":248,"y":176,"label":"2to4Decoder"},
    {"type":"In","id":"dev1","x":120,"y":192,"label":"S"},
    {"type":"BusIn","id":"dev2","x":184,"y":192,"label":"BusIn","numOutputs":2},
    {"type":"Out","id":"dev3","x":464,"y":328,"label":"S0"},
    {"type":"Out","id":"dev4","x":464,"y":408,"label":"S1"},
    {"type":"Out","id":"dev5","x":464,"y":480,"label":"S2"},
    {"type":"Out","id":"dev6","x":464,"y":552,"label":"S3"},
    {"type":"AND","id":"dev7","x":368,"y":328,"label":"AND"},
    {"type":"AND","id":"dev8","x":368,"y":408,"label":"AND"},
    {"type":"AND","id":"dev9","x":368,"y":480,"label":"AND"},
    {"type":"AND","id":"dev10","x":368,"y":552,"label":"AND"},
    {"type":"In","id":"dev11","x":176,"y":400,"label":"D"},
    {"type":"DC","id":"dev12","x":192,"y":280,"label":"DC"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev2.out0"},
    {"from":"dev0.in1","to":"dev2.out1"},
    {"from":"dev0.in2","to":"dev12.out0"},
    {"from":"dev2.in0","to":"dev1.out0"},
    {"from":"dev3.in0","to":"dev7.out0"},
    {"from":"dev4.in0","to":"dev8.out0"},
    {"from":"dev5.in0","to":"dev9.out0"},
    {"from":"dev6.in0","to":"dev10.out0"},
    {"from":"dev7.in0","to":"dev11.out0"},
    {"from":"dev7.in1","to":"dev0.out0"},
    {"from":"dev8.in0","to":"dev11.out0"},
    {"from":"dev8.in1","to":"dev0.out1"},
    {"from":"dev9.in0","to":"dev11.out0"},
    {"from":"dev9.in1","to":"dev0.out2"},
    {"from":"dev10.in0","to":"dev11.out0"},
    {"from":"dev10.in1","to":"dev0.out3"}
  ]
}
);

simcir.registerDevice('DemuxBus',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"2to4Decoder","id":"dev0","x":248,"y":176,"label":"2to4Decoder"},
    {"type":"In","id":"dev1","x":120,"y":192,"label":"S"},
    {"type":"BusIn","id":"dev2","x":184,"y":192,"label":"BusIn","numOutputs":2},
    {"type":"In","id":"dev3","x":176,"y":400,"label":"D"},
    {"type":"AndBus1","id":"dev4","x":360,"y":328,"label":"AndBus1"},
    {"type":"Out","id":"dev5","x":464,"y":328,"label":"S0"},
    {"type":"Out","id":"dev6","x":464,"y":408,"label":"S1"},
    {"type":"Out","id":"dev7","x":464,"y":480,"label":"S2"},
    {"type":"AndBus1","id":"dev8","x":360,"y":408,"label":"AndBus1"},
    {"type":"Out","id":"dev9","x":464,"y":552,"label":"S3"},
    {"type":"AndBus1","id":"dev10","x":360,"y":480,"label":"AndBus1"},
    {"type":"AndBus1","id":"dev11","x":360,"y":552,"label":"AndBus1"},
    {"type":"DC","id":"dev12","x":176,"y":288,"label":"DC"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev2.out0"},
    {"from":"dev0.in1","to":"dev2.out1"},
    {"from":"dev0.in2","to":"dev12.out0"},
    {"from":"dev2.in0","to":"dev1.out0"},
    {"from":"dev4.in0","to":"dev3.out0"},
    {"from":"dev4.in1","to":"dev0.out0"},
    {"from":"dev5.in0","to":"dev4.out0"},
    {"from":"dev6.in0","to":"dev8.out0"},
    {"from":"dev7.in0","to":"dev10.out0"},
    {"from":"dev8.in0","to":"dev3.out0"},
    {"from":"dev8.in1","to":"dev0.out1"},
    {"from":"dev9.in0","to":"dev11.out0"},
    {"from":"dev10.in0","to":"dev3.out0"},
    {"from":"dev10.in1","to":"dev0.out2"},
    {"from":"dev11.in0","to":"dev3.out0"},
    {"from":"dev11.in1","to":"dev0.out3"}
  ]
}
);

//
// Calculs
//

simcir.registerDevice('Inc',
{
  "width":1000,
  "height":600,
  "showToolbox":false,
  "devices":[
    {"type":"FullAdder","id":"dev0","x":472,"y":248,"label":"FullAdder"},
    {"type":"FullAdder","id":"dev1","x":472,"y":320,"label":"FullAdder"},
    {"type":"FullAdder","id":"dev2","x":472,"y":384,"label":"FullAdder"},
    {"type":"In","id":"dev3","x":232,"y":184,"label":"D0"},
    {"type":"Out","id":"dev4","x":624,"y":168,"label":"A0"},
    {"type":"In","id":"dev5","x":232,"y":232,"label":"D1"},
    {"type":"Out","id":"dev6","x":624,"y":232,"label":"A1"},
    {"type":"In","id":"dev7","x":232,"y":280,"label":"D2"},
    {"type":"Out","id":"dev8","x":624,"y":320,"label":"A2"},
    {"type":"In","id":"dev9","x":232,"y":328,"label":"D3"},
    {"type":"Out","id":"dev10","x":632,"y":384,"label":"A3"},
    {"type":"DC","id":"dev11","x":32,"y":224,"label":"DC"},
    {"type":"Toggle","id":"dev12","x":112,"y":184,"label":"Toggle"},
    {"type":"Toggle","id":"dev13","x":112,"y":232,"label":"Toggle"},
    {"type":"Toggle","id":"dev14","x":112,"y":280,"label":"Toggle"},
    {"type":"Toggle","id":"dev15","x":112,"y":328,"label":"Toggle"},
    {"type":"FullAdder","id":"dev16","x":472,"y":168,"label":"FullAdder"},
    {"type":"NOT","id":"dev17","x":400,"y":408,"label":"NOT"},
    {"type":"Out","id":"dev18","x":632,"y":456,"label":"C"},
    {"type":"DC","id":"dev19","x":328,"y":408,"label":"DC"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev16.out1"},
    {"from":"dev0.in1","to":"dev5.out0"},
    {"from":"dev0.in2","to":"dev17.out0"},
    {"from":"dev1.in0","to":"dev0.out1"},
    {"from":"dev1.in1","to":"dev7.out0"},
    {"from":"dev1.in2","to":"dev17.out0"},
    {"from":"dev2.in0","to":"dev1.out1"},
    {"from":"dev2.in1","to":"dev9.out0"},
    {"from":"dev2.in2","to":"dev17.out0"},
    {"from":"dev3.in0","to":"dev12.out0"},
    {"from":"dev4.in0","to":"dev16.out0"},
    {"from":"dev5.in0","to":"dev13.out0"},
    {"from":"dev6.in0","to":"dev0.out0"},
    {"from":"dev7.in0","to":"dev14.out0"},
    {"from":"dev8.in0","to":"dev1.out0"},
    {"from":"dev9.in0","to":"dev15.out0"},
    {"from":"dev10.in0","to":"dev2.out0"},
    {"from":"dev12.in0","to":"dev11.out0"},
    {"from":"dev13.in0","to":"dev11.out0"},
    {"from":"dev14.in0","to":"dev11.out0"},
    {"from":"dev15.in0","to":"dev11.out0"},
    {"from":"dev16.in0","to":"dev17.out0"},
    {"from":"dev16.in1","to":"dev3.out0"},
    {"from":"dev16.in2","to":"dev19.out0"},
    {"from":"dev17.in0","to":"dev19.out0"},
    {"from":"dev18.in0","to":"dev2.out1"}
  ]
}
);

simcir.registerDevice('Dec',
{
  "width":1000,
  "height":600,
  "showToolbox":false,
  "devices":[
    {"type":"FullAdder","id":"dev0","x":472,"y":248,"label":"FullAdder"},
    {"type":"FullAdder","id":"dev1","x":472,"y":320,"label":"FullAdder"},
    {"type":"FullAdder","id":"dev2","x":472,"y":384,"label":"FullAdder"},
    {"type":"In","id":"dev3","x":232,"y":184,"label":"D0"},
    {"type":"Out","id":"dev4","x":624,"y":168,"label":"A0"},
    {"type":"In","id":"dev5","x":232,"y":232,"label":"D1"},
    {"type":"Out","id":"dev6","x":624,"y":232,"label":"A1"},
    {"type":"In","id":"dev7","x":232,"y":280,"label":"D2"},
    {"type":"Out","id":"dev8","x":624,"y":320,"label":"A2"},
    {"type":"In","id":"dev9","x":232,"y":328,"label":"D3"},
    {"type":"Out","id":"dev10","x":632,"y":384,"label":"A3"},
    {"type":"DC","id":"dev11","x":32,"y":224,"label":"DC"},
    {"type":"Toggle","id":"dev12","x":112,"y":184,"label":"Toggle"},
    {"type":"Toggle","id":"dev13","x":112,"y":232,"label":"Toggle"},
    {"type":"Toggle","id":"dev14","x":112,"y":280,"label":"Toggle"},
    {"type":"Toggle","id":"dev15","x":112,"y":328,"label":"Toggle"},
    {"type":"FullAdder","id":"dev16","x":472,"y":168,"label":"FullAdder"},
    {"type":"NOT","id":"dev17","x":400,"y":408,"label":"NOT"},
    {"type":"Out","id":"dev18","x":632,"y":456,"label":"C"},
    {"type":"DC","id":"dev19","x":328,"y":408,"label":"DC"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev16.out1"},
    {"from":"dev0.in1","to":"dev5.out0"},
    {"from":"dev0.in2","to":"dev19.out0"},
    {"from":"dev1.in0","to":"dev0.out1"},
    {"from":"dev1.in1","to":"dev7.out0"},
    {"from":"dev1.in2","to":"dev19.out0"},
    {"from":"dev2.in0","to":"dev1.out1"},
    {"from":"dev2.in1","to":"dev9.out0"},
    {"from":"dev2.in2","to":"dev19.out0"},
    {"from":"dev3.in0","to":"dev12.out0"},
    {"from":"dev4.in0","to":"dev16.out0"},
    {"from":"dev5.in0","to":"dev13.out0"},
    {"from":"dev6.in0","to":"dev0.out0"},
    {"from":"dev7.in0","to":"dev14.out0"},
    {"from":"dev8.in0","to":"dev1.out0"},
    {"from":"dev9.in0","to":"dev15.out0"},
    {"from":"dev10.in0","to":"dev2.out0"},
    {"from":"dev12.in0","to":"dev11.out0"},
    {"from":"dev13.in0","to":"dev11.out0"},
    {"from":"dev14.in0","to":"dev11.out0"},
    {"from":"dev15.in0","to":"dev11.out0"},
    {"from":"dev16.in0","to":"dev17.out0"},
    {"from":"dev16.in1","to":"dev3.out0"},
    {"from":"dev16.in2","to":"dev19.out0"},
    {"from":"dev17.in0","to":"dev19.out0"},
    {"from":"dev18.in0","to":"dev2.out1"}
  ]
}
);

simcir.registerDevice('IncBus',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"Inc","id":"dev0","x":248,"y":392,"label":"Inc"},
    {"type":"BusOut","id":"dev1","x":360,"y":400,"label":"BusOut","numInputs":4},
    {"type":"BusIn","id":"dev2","x":176,"y":400,"label":"BusIn","numOutputs":4},
    {"type":"Out","id":"dev3","x":464,"y":416,"label":"A"},
    {"type":"In","id":"dev4","x":88,"y":416,"label":"D"},
    {"type":"Out","id":"dev5","x":464,"y":488,"label":"C"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev2.out0"},
    {"from":"dev0.in1","to":"dev2.out1"},
    {"from":"dev0.in2","to":"dev2.out2"},
    {"from":"dev0.in3","to":"dev2.out3"},
    {"from":"dev1.in0","to":"dev0.out0"},
    {"from":"dev1.in1","to":"dev0.out1"},
    {"from":"dev1.in2","to":"dev0.out2"},
    {"from":"dev1.in3","to":"dev0.out3"},
    {"from":"dev2.in0","to":"dev4.out0"},
    {"from":"dev3.in0","to":"dev1.out0"},
    {"from":"dev5.in0","to":"dev0.out4"}
  ]
}
);

simcir.registerDevice('DecBus',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"Dec","id":"dev0","x":248,"y":392,"label":"Dec"},
    {"type":"BusOut","id":"dev1","x":360,"y":400,"label":"BusOut","numInputs":4},
    {"type":"BusIn","id":"dev2","x":176,"y":400,"label":"BusIn","numOutputs":4},
    {"type":"Out","id":"dev3","x":464,"y":416,"label":"A"},
    {"type":"In","id":"dev4","x":88,"y":416,"label":"D"},
    {"type":"Out","id":"dev5","x":464,"y":488,"label":"C"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev2.out0"},
    {"from":"dev0.in1","to":"dev2.out1"},
    {"from":"dev0.in2","to":"dev2.out2"},
    {"from":"dev0.in3","to":"dev2.out3"},
    {"from":"dev1.in0","to":"dev0.out0"},
    {"from":"dev1.in1","to":"dev0.out1"},
    {"from":"dev1.in2","to":"dev0.out2"},
    {"from":"dev1.in3","to":"dev0.out3"},
    {"from":"dev2.in0","to":"dev4.out0"},
    {"from":"dev3.in0","to":"dev1.out0"},
    {"from":"dev5.in0","to":"dev0.out4"}
  ]
}
);

simcir.registerDevice('AddBus',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"4bitAdder","id":"dev0","x":432,"y":240,"label":"4bitAdder"},
    {"type":"BusOut","id":"dev1","x":560,"y":288,"label":"BusOut"},
    {"type":"BusIn","id":"dev2","x":344,"y":264,"label":"BusIn"},
    {"type":"BusIn","id":"dev3","x":344,"y":336,"label":"BusIn"},
    {"type":"In","id":"dev4","x":320,"y":192,"label":"Cin"},
    {"type":"In","id":"dev5","x":224,"y":272,"label":"A"},
    {"type":"In","id":"dev6","x":224,"y":344,"label":"B"},
    {"type":"Out","id":"dev7","x":664,"y":352,"label":"Cout"},
    {"type":"Out","id":"dev8","x":664,"y":288,"label":"S"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev4.out0"},
    {"from":"dev0.in1","to":"dev2.out0"},
    {"from":"dev0.in2","to":"dev2.out1"},
    {"from":"dev0.in3","to":"dev2.out2"},
    {"from":"dev0.in4","to":"dev2.out3"},
    {"from":"dev0.in5","to":"dev3.out0"},
    {"from":"dev0.in6","to":"dev3.out1"},
    {"from":"dev0.in7","to":"dev3.out2"},
    {"from":"dev0.in8","to":"dev3.out3"},
    {"from":"dev1.in0","to":"dev0.out0"},
    {"from":"dev1.in1","to":"dev0.out1"},
    {"from":"dev1.in2","to":"dev0.out2"},
    {"from":"dev1.in3","to":"dev0.out3"},
    {"from":"dev2.in0","to":"dev5.out0"},
    {"from":"dev3.in0","to":"dev6.out0"},
    {"from":"dev7.in0","to":"dev0.out4"},
    {"from":"dev8.in0","to":"dev1.out0"}
  ]
}
);

simcir.registerDevice('NegBus',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"NOT","id":"dev0","x":352,"y":88,"label":"NOT"},
    {"type":"NOT","id":"dev1","x":352,"y":136,"label":"NOT"},
    {"type":"NOT","id":"dev2","x":352,"y":184,"label":"NOT"},
    {"type":"NOT","id":"dev3","x":352,"y":232,"label":"NOT"},
    {"type":"IncBus","id":"dev4","x":520,"y":160,"label":"IncBus"},
    {"type":"Out","id":"dev5","x":616,"y":152,"label":"D"},
    {"type":"BusIn","id":"dev6","x":264,"y":152,"label":"BusIn"},
    {"type":"In","id":"dev7","x":200,"y":160,"label":"A"},
    {"type":"BusOut","id":"dev8","x":440,"y":152,"label":"BusOut"},
    {"type":"RotaryEncoderBus","id":"dev9","x":88,"y":144,"label":"RotaryEncoderBus"},
    {"type":"4bit7segBus","id":"dev10","x":184,"y":16,"label":"4bit7segBus"},
    {"type":"4bit7segBus","id":"dev11","x":688,"y":24,"label":"4bit7segBus"},
    {"type":"DC","id":"dev12","x":16,"y":160,"label":"DC"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev6.out0"},
    {"from":"dev1.in0","to":"dev6.out1"},
    {"from":"dev2.in0","to":"dev6.out2"},
    {"from":"dev3.in0","to":"dev6.out3"},
    {"from":"dev4.in0","to":"dev8.out0"},
    {"from":"dev5.in0","to":"dev4.out0"},
    {"from":"dev6.in0","to":"dev7.out0"},
    {"from":"dev7.in0","to":"dev9.out0"},
    {"from":"dev8.in0","to":"dev0.out0"},
    {"from":"dev8.in1","to":"dev1.out0"},
    {"from":"dev8.in2","to":"dev2.out0"},
    {"from":"dev8.in3","to":"dev3.out0"},
    {"from":"dev9.in0","to":"dev12.out0"},
    {"from":"dev10.in0","to":"dev9.out0"},
    {"from":"dev11.in0","to":"dev5.out0"}
  ]
}
);

simcir.registerDevice('SubBus',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"AddBus","id":"dev0","x":456,"y":192,"label":"AddBus"},
    {"type":"In","id":"dev1","x":232,"y":208,"label":"B"},
    {"type":"In","id":"dev2","x":232,"y":152,"label":"A"},
    {"type":"4bit7segBus","id":"dev3","x":216,"y":304,"label":"4bit7segBus"},
    {"type":"RotaryEncoderBus","id":"dev4","x":112,"y":120,"label":"RotaryEncoderBus"},
    {"type":"RotaryEncoderBus","id":"dev5","x":112,"y":208,"label":"RotaryEncoderBus"},
    {"type":"4bit7segBus","id":"dev6","x":216,"y":16,"label":"4bit7segBus"},
    {"type":"DC","id":"dev7","x":24,"y":184,"label":"DC"},
    {"type":"In","id":"dev8","x":376,"y":280,"label":"Cin"},
    {"type":"4bit7segBus","id":"dev9","x":584,"y":72,"label":"4bit7segBus"},
    {"type":"Out","id":"dev10","x":552,"y":192,"label":"S"},
    {"type":"Out","id":"dev11","x":552,"y":280,"label":"Cout"},
    {"type":"NegBus","id":"dev12","x":328,"y":168,"label":"NegBus"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev12.out0"},
    {"from":"dev0.in1","to":"dev1.out0"},
    {"from":"dev0.in2","to":"dev8.out0"},
    {"from":"dev1.in0","to":"dev5.out0"},
    {"from":"dev2.in0","to":"dev4.out0"},
    {"from":"dev3.in0","to":"dev5.out0"},
    {"from":"dev4.in0","to":"dev7.out0"},
    {"from":"dev5.in0","to":"dev7.out0"},
    {"from":"dev6.in0","to":"dev4.out0"},
    {"from":"dev9.in0","to":"dev0.out0"},
    {"from":"dev10.in0","to":"dev0.out0"},
    {"from":"dev11.in0","to":"dev0.out1"},
    {"from":"dev12.in0","to":"dev2.out0"}
  ]
}
);

simcir.registerDevice('EqualBus',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"In","id":"dev0","x":232,"y":304,"label":"In"},
    {"type":"RotaryEncoderBus","id":"dev1","x":120,"y":288,"label":"RotaryEncoderBus"},
    {"type":"RotaryEncoderBus","id":"dev2","x":120,"y":400,"label":"RotaryEncoderBus"},
    {"type":"DC","id":"dev3","x":32,"y":360,"label":"DC"},
    {"type":"In","id":"dev4","x":232,"y":416,"label":"In"},
    {"type":"BusIn","id":"dev5","x":296,"y":408,"label":"BusIn"},
    {"type":"BusIn","id":"dev6","x":296,"y":304,"label":"BusIn"},
    {"type":"XNOR","id":"dev7","x":376,"y":280,"label":"XNOR"},
    {"type":"XNOR","id":"dev8","x":376,"y":336,"label":"XNOR"},
    {"type":"XNOR","id":"dev9","x":376,"y":392,"label":"XNOR"},
    {"type":"XNOR","id":"dev10","x":376,"y":448,"label":"XNOR"},
    {"type":"AND","id":"dev11","x":456,"y":360,"label":"AND","numInputs":4},
    {"type":"Out","id":"dev12","x":512,"y":360,"label":"Out"},
    {"type":"LED","id":"dev13","x":568,"y":360,"label":"LED"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev1.out0"},
    {"from":"dev1.in0","to":"dev3.out0"},
    {"from":"dev2.in0","to":"dev3.out0"},
    {"from":"dev4.in0","to":"dev2.out0"},
    {"from":"dev5.in0","to":"dev4.out0"},
    {"from":"dev6.in0","to":"dev0.out0"},
    {"from":"dev7.in0","to":"dev6.out0"},
    {"from":"dev7.in1","to":"dev5.out0"},
    {"from":"dev8.in0","to":"dev6.out1"},
    {"from":"dev8.in1","to":"dev5.out1"},
    {"from":"dev9.in0","to":"dev6.out2"},
    {"from":"dev9.in1","to":"dev5.out2"},
    {"from":"dev10.in0","to":"dev6.out3"},
    {"from":"dev10.in1","to":"dev5.out3"},
    {"from":"dev11.in0","to":"dev7.out0"},
    {"from":"dev11.in1","to":"dev8.out0"},
    {"from":"dev11.in2","to":"dev9.out0"},
    {"from":"dev11.in3","to":"dev10.out0"},
    {"from":"dev12.in0","to":"dev11.out0"},
    {"from":"dev13.in0","to":"dev12.out0"}
  ]
}
);

// Ancienne version, ne fonctionne pas bien car apparemment DC n'est pas inclut
// dans le circuit...
//{
//  "width":1000,
//  "height":600,
//  "showToolbox":false,
//  "toolbox":[
//  ],
//     "devices":[
//    {"type":"FullAdder","id":"dev0","x":472,"y":168,"label":"FullAdder"},
//    {"type":"FullAdder","id":"dev1","x":472,"y":248,"label":"FullAdder"},
//    {"type":"FullAdder","id":"dev2","x":472,"y":320,"label":"FullAdder"},
//    {"type":"FullAdder","id":"dev3","x":472,"y":384,"label":"FullAdder"},
//    {"type":"DC","id":"dev4","x":344,"y":408,"label":"DC"},
//    {"type":"NOT","id":"dev5","x":400,"y":408,"label":"NOT"},
//    {"type":"In","id":"dev6","x":384,"y":176,"label":"D0"},
//    {"type":"Out","id":"dev7","x":584,"y":168,"label":"A0"},
//    {"type":"In","id":"dev8","x":384,"y":224,"label":"D1"},
//    {"type":"Out","id":"dev9","x":584,"y":232,"label":"A1"},
//    {"type":"In","id":"dev10","x":384,"y":272,"label":"D2"},
//    {"type":"Out","id":"dev11","x":584,"y":320,"label":"A2"},
//    {"type":"In","id":"dev12","x":384,"y":320,"label":"D3"},
//    {"type":"Out","id":"dev13","x":592,"y":384,"label":"A3"},
//    {"type":"DC","id":"dev14","x":240,"y":224,"label":"DC"},
//    {"type":"Toggle","id":"dev15","x":312,"y":176,"label":"Toggle"},
//    {"type":"Toggle","id":"dev16","x":320,"y":232,"label":"Toggle"},
//    {"type":"Toggle","id":"dev17","x":320,"y":280,"label":"Toggle"},
//    {"type":"Toggle","id":"dev18","x":320,"y":328,"label":"Toggle"}
//  ],
//  "connectors":[
//    {"from":"dev0.in0","to":"dev5.out0"},
//    {"from":"dev0.in1","to":"dev6.out0"},
//    {"from":"dev0.in2","to":"dev4.out0"},
//    {"from":"dev1.in0","to":"dev0.out1"},
//    {"from":"dev1.in1","to":"dev8.out0"},
//    {"from":"dev1.in2","to":"dev5.out0"},
//    {"from":"dev2.in0","to":"dev1.out1"},
//    {"from":"dev2.in1","to":"dev10.out0"},
//    {"from":"dev2.in2","to":"dev5.out0"},
//    {"from":"dev3.in0","to":"dev2.out1"},
//    {"from":"dev3.in1","to":"dev12.out0"},
//    {"from":"dev3.in2","to":"dev5.out0"},
//    {"from":"dev5.in0","to":"dev4.out0"},
//    {"from":"dev6.in0","to":"dev15.out0"},
//    {"from":"dev7.in0","to":"dev0.out0"},
//    {"from":"dev8.in0","to":"dev16.out0"},
//    {"from":"dev9.in0","to":"dev1.out0"},
//    {"from":"dev10.in0","to":"dev17.out0"},
//    {"from":"dev11.in0","to":"dev2.out0"},
//    {"from":"dev12.in0","to":"dev18.out0"},
//    {"from":"dev13.in0","to":"dev3.out0"},
//    {"from":"dev15.in0","to":"dev14.out0"},
//    {"from":"dev16.in0","to":"dev14.out0"},
//    {"from":"dev17.in0","to":"dev14.out0"},
//    {"from":"dev18.in0","to":"dev14.out0"}
//  ]
//}

simcir.registerDevice('AndBus1',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"AND","id":"dev0","x":264,"y":280,"label":"AND"},
    {"type":"BusIn","id":"dev1","x":176,"y":280,"label":"BusIn"},
    {"type":"AND","id":"dev2","x":264,"y":216,"label":"AND"},
    {"type":"AND","id":"dev3","x":264,"y":344,"label":"AND"},
    {"type":"AND","id":"dev4","x":264,"y":408,"label":"AND"},
    {"type":"In","id":"dev5","x":96,"y":280,"label":"Dx"},
    {"type":"In","id":"dev6","x":184,"y":200,"label":"D0"},
    {"type":"BusOut","id":"dev7","x":368,"y":280,"label":"BusOut"},
    {"type":"Out","id":"dev8","x":456,"y":288,"label":"A"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev6.out0"},
    {"from":"dev0.in1","to":"dev1.out1"},
    {"from":"dev1.in0","to":"dev5.out0"},
    {"from":"dev2.in0","to":"dev6.out0"},
    {"from":"dev2.in1","to":"dev1.out0"},
    {"from":"dev3.in0","to":"dev6.out0"},
    {"from":"dev3.in1","to":"dev1.out2"},
    {"from":"dev4.in0","to":"dev6.out0"},
    {"from":"dev4.in1","to":"dev1.out3"},
    {"from":"dev7.in0","to":"dev2.out0"},
    {"from":"dev7.in1","to":"dev0.out0"},
    {"from":"dev7.in2","to":"dev3.out0"},
    {"from":"dev7.in3","to":"dev4.out0"},
    {"from":"dev8.in0","to":"dev7.out0"}
  ]
}
);

simcir.registerDevice('OrBus',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"OR","id":"dev0","x":304,"y":240,"label":"OR"},
    {"type":"OR","id":"dev1","x":304,"y":296,"label":"OR"},
    {"type":"OR","id":"dev2","x":304,"y":360,"label":"OR"},
    {"type":"OR","id":"dev3","x":304,"y":432,"label":"OR"},
    {"type":"BusIn","id":"dev4","x":192,"y":360,"label":"BusIn"},
    {"type":"BusIn","id":"dev5","x":192,"y":280,"label":"BusIn"},
    {"type":"BusOut","id":"dev6","x":424,"y":296,"label":"BusOut"},
    {"type":"In","id":"dev7","x":112,"y":288,"label":"In"},
    {"type":"In","id":"dev8","x":112,"y":368,"label":"In"},
    {"type":"Out","id":"dev9","x":520,"y":304,"label":"Out"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev5.out0"},
    {"from":"dev0.in1","to":"dev4.out0"},
    {"from":"dev1.in0","to":"dev5.out1"},
    {"from":"dev1.in1","to":"dev4.out1"},
    {"from":"dev2.in0","to":"dev5.out2"},
    {"from":"dev2.in1","to":"dev4.out2"},
    {"from":"dev3.in0","to":"dev5.out3"},
    {"from":"dev3.in1","to":"dev4.out3"},
    {"from":"dev4.in0","to":"dev8.out0"},
    {"from":"dev5.in0","to":"dev7.out0"},
    {"from":"dev6.in0","to":"dev0.out0"},
    {"from":"dev6.in1","to":"dev1.out0"},
    {"from":"dev6.in2","to":"dev2.out0"},
    {"from":"dev6.in3","to":"dev3.out0"},
    {"from":"dev9.in0","to":"dev6.out0"}
  ]
}
);

//
// Registres
//

simcir.registerDevice('D',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"In","id":"dev0","x":152,"y":272,"label":"CLK"},
    {"type":"NOT","id":"dev1","x":216,"y":264,"label":"NOT"},
    {"type":"In","id":"dev2","x":152,"y":208,"label":"D"},
    {"type":"D-FF","id":"dev3","x":280,"y":248,"label":"D-FF"},
    {"type":"Out","id":"dev4","x":384,"y":208,"label":"Q"},
    {"type":"Out","id":"dev5","x":384,"y":272,"label":"~Q"},
    {"type":"DC","id":"dev6","x":48,"y":272,"label":"DC"},
    {"type":"Toggle","id":"dev7","x":104,"y":272,"label":"Toggle"},
    {"type":"pinright","id":"dev8","x":432,"y":136,"label":""},
    {"type":"pinleft","id":"dev9","x":432,"y":280,"label":""},
    {"type":"pinright","id":"dev10","x":152,"y":136,"label":""}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev7.out0"},
    {"from":"dev1.in0","to":"dev0.out0"},
    {"from":"dev2.in0","to":"dev10.out0"},
    {"from":"dev3.in0","to":"dev2.out0"},
    {"from":"dev3.in1","to":"dev1.out0"},
    {"from":"dev4.in0","to":"dev3.out0"},
    {"from":"dev5.in0","to":"dev3.out1"},
    {"from":"dev7.in0","to":"dev6.out0"},
    {"from":"dev8.in0","to":"dev9.out0"},
    {"from":"dev9.in0","to":"dev5.out0"},
    {"from":"dev10.in0","to":"dev8.out0"}
  ]
}
);

simcir.registerDevice('D-E',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"D","id":"dev0","x":392,"y":352,"label":"D"},
    {"type":"Out","id":"dev1","x":520,"y":384,"label":"~Q"},
    {"type":"Mux2","id":"dev2","x":296,"y":336,"label":"Mux2"},
    {"type":"pinright","id":"dev3","x":264,"y":256,"label":""},
    {"type":"In","id":"dev4","x":360,"y":504,"label":"CLK"},
    {"type":"Out","id":"dev5","x":520,"y":328,"label":"Q"},
    {"type":"pinright","id":"dev6","x":472,"y":256,"label":""},
    {"type":"In","id":"dev7","x":176,"y":312,"label":"E"},
    {"type":"In","id":"dev8","x":176,"y":368,"label":"D"},
    {"type":"DC","id":"dev9","x":32,"y":336,"label":"DC"},
    {"type":"Toggle","id":"dev10","x":104,"y":312,"label":"Toggle"},
    {"type":"Toggle","id":"dev11","x":104,"y":368,"label":"Toggle"},
    {"type":"PushOn","id":"dev12","x":104,"y":440,"label":"PushOn"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev2.out0"},
    {"from":"dev0.in1","to":"dev4.out0"},
    {"from":"dev1.in0","to":"dev0.out1"},
    {"from":"dev2.in0","to":"dev7.out0"},
    {"from":"dev2.in1","to":"dev3.out0"},
    {"from":"dev2.in2","to":"dev8.out0"},
    {"from":"dev3.in0","to":"dev6.out0"},
    {"from":"dev4.in0","to":"dev12.out0"},
    {"from":"dev5.in0","to":"dev0.out0"},
    {"from":"dev6.in0","to":"dev0.out0"},
    {"from":"dev7.in0","to":"dev10.out0"},
    {"from":"dev8.in0","to":"dev11.out0"},
    {"from":"dev10.in0","to":"dev9.out0"},
    {"from":"dev11.in0","to":"dev9.out0"},
    {"from":"dev12.in0","to":"dev9.out0"}
  ]
}
);

simcir.registerDevice('Reg4',
{
  "width":800,
  "height":600,
  "showToolbox":false,
  "toolbox":[
  ],
  "devices":[
    {"type":"D","id":"dev0","x":304,"y":200,"label":"D"},
    {"type":"D","id":"dev1","x":304,"y":264,"label":"D"},
    {"type":"D","id":"dev2","x":304,"y":336,"label":"D"},
    {"type":"D","id":"dev3","x":304,"y":408,"label":"D"},
    {"type":"In","id":"dev4","x":232,"y":336,"label":"D0"},
    {"type":"In","id":"dev5","x":232,"y":408,"label":"D1"},
    {"type":"In","id":"dev6","x":232,"y":200,"label":"D2"},
    {"type":"In","id":"dev7","x":232,"y":264,"label":"D3"},
    {"type":"In","id":"dev8","x":232,"y":472,"label":"CLK"},
    {"type":"Out","id":"dev9","x":416,"y":200,"label":"Q0"},
    {"type":"Out","id":"dev10","x":416,"y":264,"label":"Q1"},
    {"type":"Out","id":"dev11","x":416,"y":336,"label":"Q2"},
    {"type":"Out","id":"dev12","x":416,"y":408,"label":"Q3"},
    {"type":"Toggle","id":"dev13","x":176,"y":200,"label":"Toggle"},
    {"type":"Toggle","id":"dev14","x":176,"y":264,"label":"Toggle"},
    {"type":"Toggle","id":"dev15","x":176,"y":336,"label":"Toggle"},
    {"type":"Toggle","id":"dev16","x":176,"y":408,"label":"Toggle"},
    {"type":"DC","id":"dev17","x":104,"y":304,"label":"DC"},
    {"type":"PushOn","id":"dev18","x":176,"y":472,"label":"PushOn"},
    {"type":"LED","id":"dev19","x":496,"y":200,"label":"LED"},
    {"type":"LED","id":"dev20","x":496,"y":264,"label":"LED"},
    {"type":"LED","id":"dev21","x":496,"y":336,"label":"LED"},
    {"type":"LED","id":"dev22","x":496,"y":408,"label":"LED"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev6.out0"},
    {"from":"dev0.in1","to":"dev8.out0"},
    {"from":"dev1.in0","to":"dev7.out0"},
    {"from":"dev1.in1","to":"dev8.out0"},
    {"from":"dev2.in0","to":"dev4.out0"},
    {"from":"dev2.in1","to":"dev8.out0"},
    {"from":"dev3.in0","to":"dev5.out0"},
    {"from":"dev3.in1","to":"dev8.out0"},
    {"from":"dev4.in0","to":"dev15.out0"},
    {"from":"dev5.in0","to":"dev16.out0"},
    {"from":"dev6.in0","to":"dev13.out0"},
    {"from":"dev7.in0","to":"dev14.out0"},
    {"from":"dev8.in0","to":"dev18.out0"},
    {"from":"dev9.in0","to":"dev0.out0"},
    {"from":"dev10.in0","to":"dev1.out0"},
    {"from":"dev11.in0","to":"dev2.out0"},
    {"from":"dev12.in0","to":"dev3.out0"},
    {"from":"dev13.in0","to":"dev17.out0"},
    {"from":"dev14.in0","to":"dev17.out0"},
    {"from":"dev15.in0","to":"dev17.out0"},
    {"from":"dev16.in0","to":"dev17.out0"},
    {"from":"dev18.in0","to":"dev17.out0"},
    {"from":"dev19.in0","to":"dev9.out0"},
    {"from":"dev20.in0","to":"dev10.out0"},
    {"from":"dev21.in0","to":"dev11.out0"},
    {"from":"dev22.in0","to":"dev12.out0"}
  ]
}
);

simcir.registerDevice('RegBus',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"BusIn","id":"dev0","x":312,"y":320,"label":"BusIn"},
    {"type":"BusOut","id":"dev1","x":536,"y":312,"label":"BusOut"},
    {"type":"Reg4","id":"dev2","x":408,"y":304,"label":"Reg4"},
    {"type":"In","id":"dev3","x":216,"y":328,"label":"D"},
    {"type":"Out","id":"dev4","x":632,"y":320,"label":"Q"},
    {"type":"In","id":"dev5","x":312,"y":392,"label":"Clk"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev3.out0"},
    {"from":"dev1.in0","to":"dev2.out0"},
    {"from":"dev1.in1","to":"dev2.out1"},
    {"from":"dev1.in2","to":"dev2.out2"},
    {"from":"dev1.in3","to":"dev2.out3"},
    {"from":"dev2.in0","to":"dev0.out0"},
    {"from":"dev2.in1","to":"dev0.out1"},
    {"from":"dev2.in2","to":"dev0.out2"},
    {"from":"dev2.in3","to":"dev0.out3"},
    {"from":"dev2.in4","to":"dev5.out0"},
    {"from":"dev4.in0","to":"dev1.out0"}
  ]
}
);

simcir.registerDevice('RegBus-E',
{
  "width":1200,
  "height":800,
  "showToolbox":false,
  "devices":[
    {"type":"RegBus","id":"dev0","x":392,"y":352,"label":"RegBus"},
    {"type":"MuxBus2","id":"dev1","x":296,"y":336,"label":"MuxBus2"},
    {"type":"4>4","id":"dev2","x":264,"y":256,"label":""},
    {"type":"In","id":"dev3","x":360,"y":504,"label":"CLK"},
    {"type":"Out","id":"dev4","x":520,"y":328,"label":"Q"},
    {"type":"4>4","id":"dev5","x":472,"y":256,"label":""},
    {"type":"In","id":"dev6","x":176,"y":312,"label":"E"},
    {"type":"In","id":"dev7","x":176,"y":368,"label":"D"},
    {"type":"4bit7segBus","id":"dev8","x":616,"y":312,"label":"4bit7segBus"},
    {"type":"RotaryEncoderBus","id":"dev9","x":88,"y":352,"label":"RotaryEncoderBus"},
    {"type":"DC","id":"dev10","x":8,"y":328,"label":"DC"},
    {"type":"Toggle","id":"dev11","x":88,"y":296,"label":"Toggle"},
    {"type":"OSC","id":"dev12","x":248,"y":504,"label":"OSC"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev1.out0"},
    {"from":"dev0.in1","to":"dev3.out0"},
    {"from":"dev1.in0","to":"dev6.out0"},
    {"from":"dev1.in1","to":"dev2.out0"},
    {"from":"dev1.in2","to":"dev7.out0"},
    {"from":"dev2.in0","to":"dev5.out0"},
    {"from":"dev3.in0","to":"dev12.out0"},
    {"from":"dev4.in0","to":"dev0.out0"},
    {"from":"dev5.in0","to":"dev0.out0"},
    {"from":"dev6.in0","to":"dev11.out0"},
    {"from":"dev7.in0","to":"dev9.out0"},
    {"from":"dev8.in0","to":"dev4.out0"},
    {"from":"dev9.in0","to":"dev10.out0"},
    {"from":"dev11.in0","to":"dev10.out0"}
  ]
}
);

simcir.registerDevice('Cnt-N',
{
  "width":1200,
  "height":800,
  "showToolbox":true,
  "devices":[
    {"type":"RegBus","id":"dev0","x":488,"y":192,"label":"RegBus"},
    {"type":"4>4","id":"dev1","x":24,"y":80,"label":""},
    {"type":"4>4","id":"dev2","x":576,"y":80,"label":""},
    {"type":"4<4","id":"dev3","x":576,"y":200,"label":""},
    {"type":"RotaryEncoderBus","id":"dev4","x":88,"y":544,"label":"RotaryEncoderBus"},
    {"type":"DC","id":"dev5","x":24,"y":560,"label":"DC"},
    {"type":"OSC","id":"dev6","x":344,"y":616,"label":"OSC"},
    {"type":"Toggle","id":"dev7","x":384,"y":616,"label":"Toggle"},
    {"type":"DC","id":"dev8","x":8,"y":472,"label":"DC"},
    {"type":"4bit7segBus","id":"dev9","x":160,"y":544,"label":"4bit7segBus"},
    {"type":"Toggle","id":"dev10","x":56,"y":472,"label":"Toggle"},
    {"type":"MuxBus2","id":"dev11","x":192,"y":176,"label":"MuxBus2"},
    {"type":"MuxBus2","id":"dev12","x":400,"y":176,"label":"MuxBus2"},
    {"type":"In","id":"dev13","x":432,"y":616,"label":"Clk"},
    {"type":"In","id":"dev14","x":120,"y":472,"label":"A"},
    {"type":"In","id":"dev15","x":216,"y":496,"label":"N"},
    {"type":"4<4","id":"dev16","x":24,"y":216,"label":""},
    {"type":"IncBus","id":"dev17","x":64,"y":208,"label":"IncBus"},
    {"type":"4bit7segBus","id":"dev18","x":624,"y":216,"label":"4bit7segBus"},
    {"type":"Out","id":"dev19","x":624,"y":136,"label":"Q"},
    {"type":"4>4","id":"dev20","x":536,"y":248,"label":""},
    {"type":"4<4","id":"dev21","x":152,"y":192,"label":""},
    {"type":"4>4","id":"dev22","x":152,"y":248,"label":""},
    {"type":"EqualBus","id":"dev23","x":296,"y":312,"label":"EqualBus"},
    {"type":"4<4","id":"dev24","x":272,"y":312,"label":""},
    {"type":"pinleft","id":"dev25","x":376,"y":176,"label":""},
    {"type":"4bit7segBus","id":"dev26","x":288,"y":112,"label":"4bit7segBus"},
    {"type":"4bit7segBus","id":"dev27","x":144,"y":96,"label":"4bit7segBus"},
    {"type":"Out","id":"dev28","x":736,"y":312,"label":"C"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev12.out0"},
    {"from":"dev0.in1","to":"dev13.out0"},
    {"from":"dev1.in0","to":"dev2.out0"},
    {"from":"dev2.in0","to":"dev3.out0"},
    {"from":"dev3.in0","to":"dev0.out0"},
    {"from":"dev4.in0","to":"dev5.out0"},
    {"from":"dev7.in0","to":"dev6.out0"},
    {"from":"dev9.in0","to":"dev4.out0"},
    {"from":"dev10.in0","to":"dev8.out0"},
    {"from":"dev11.in0","to":"dev14.out0"},
    {"from":"dev11.in1","to":"dev21.out0"},
    {"from":"dev11.in2","to":"dev17.out0"},
    {"from":"dev12.in0","to":"dev25.out0"},
    {"from":"dev12.in1","to":"dev11.out0"},
    {"from":"dev13.in0","to":"dev7.out0"},
    {"from":"dev14.in0","to":"dev10.out0"},
    {"from":"dev15.in0","to":"dev4.out0"},
    {"from":"dev16.in0","to":"dev1.out0"},
    {"from":"dev17.in0","to":"dev16.out0"},
    {"from":"dev18.in0","to":"dev0.out0"},
    {"from":"dev19.in0","to":"dev0.out0"},
    {"from":"dev20.in0","to":"dev0.out0"},
    {"from":"dev21.in0","to":"dev22.out0"},
    {"from":"dev22.in0","to":"dev20.out0"},
    {"from":"dev23.in0","to":"dev24.out0"},
    {"from":"dev23.in1","to":"dev15.out0"},
    {"from":"dev24.in0","to":"dev11.out0"},
    {"from":"dev25.in0","to":"dev23.out0"},
    {"from":"dev26.in0","to":"dev11.out0"},
    {"from":"dev27.in0","to":"dev17.out0"},
    {"from":"dev28.in0","to":"dev23.out0"}
  ]
}
);

simcir.registerDevice('DecCnt-N',
{
  "width":1200,
  "height":800,
  "showToolbox":true,
  "devices":[
    {"type":"RegBus","id":"dev0","x":520,"y":192,"label":"RegBus"},
    {"type":"4>4","id":"dev1","x":24,"y":80,"label":""},
    {"type":"4>4","id":"dev2","x":608,"y":80,"label":""},
    {"type":"4<4","id":"dev3","x":608,"y":200,"label":""},
    {"type":"RotaryEncoderBus","id":"dev4","x":88,"y":544,"label":"RotaryEncoderBus"},
    {"type":"DC","id":"dev5","x":24,"y":560,"label":"DC"},
    {"type":"OSC","id":"dev6","x":400,"y":616,"label":"OSC"},
    {"type":"Toggle","id":"dev7","x":440,"y":616,"label":"Toggle"},
    {"type":"DC","id":"dev8","x":8,"y":448,"label":"DC"},
    {"type":"4bit7segBus","id":"dev9","x":160,"y":544,"label":"4bit7segBus"},
    {"type":"Toggle","id":"dev10","x":56,"y":448,"label":"Toggle"},
    {"type":"MuxBus2","id":"dev11","x":216,"y":176,"label":"MuxBus2"},
    {"type":"MuxBus2","id":"dev12","x":432,"y":176,"label":"MuxBus2"},
    {"type":"In","id":"dev13","x":488,"y":616,"label":"Clk"},
    {"type":"4<4","id":"dev14","x":24,"y":200,"label":""},
    {"type":"Out","id":"dev15","x":656,"y":136,"label":"Q"},
    {"type":"4>4","id":"dev16","x":568,"y":248,"label":""},
    {"type":"EqualBus","id":"dev17","x":624,"y":312,"label":"EqualBus"},
    {"type":"4bit7segBus","id":"dev18","x":312,"y":112,"label":"4bit7segBus"},
    {"type":"4bit7segBus","id":"dev19","x":144,"y":96,"label":"4bit7segBus"},
    {"type":"Out","id":"dev20","x":752,"y":312,"label":"IRQ"},
    {"type":"4<4","id":"dev21","x":408,"y":208,"label":""},
    {"type":"DecBus","id":"dev22","x":64,"y":192,"label":"DecBus"},
    {"type":"In","id":"dev23","x":120,"y":448,"label":"R"},
    {"type":"In","id":"dev24","x":176,"y":488,"label":"D"},
    {"type":"4>4","id":"dev25","x":152,"y":248,"label":""},
    {"type":"pinleft","id":"dev26","x":192,"y":176,"label":""},
    {"type":"pinright","id":"dev27","x":192,"y":376,"label":""},
    {"type":"pinright","id":"dev28","x":672,"y":376,"label":""},
    {"type":"4<4","id":"dev29","x":152,"y":208,"label":""},
    {"type":"pinleft","id":"dev30","x":392,"y":176,"label":""},
    {"type":"pinleft","id":"dev31","x":376,"y":456,"label":""},
    {"type":"4<4","id":"dev32","x":392,"y":496,"label":""},
    {"type":"4bit7segBus","id":"dev33","x":688,"y":176,"label":"4bit7segBus"}
  ],
  "connectors":[
    {"from":"dev0.in0","to":"dev12.out0"},
    {"from":"dev0.in1","to":"dev13.out0"},
    {"from":"dev1.in0","to":"dev2.out0"},
    {"from":"dev2.in0","to":"dev3.out0"},
    {"from":"dev3.in0","to":"dev0.out0"},
    {"from":"dev4.in0","to":"dev5.out0"},
    {"from":"dev7.in0","to":"dev6.out0"},
    {"from":"dev9.in0","to":"dev4.out0"},
    {"from":"dev10.in0","to":"dev8.out0"},
    {"from":"dev11.in0","to":"dev26.out0"},
    {"from":"dev11.in1","to":"dev22.out0"},
    {"from":"dev11.in2","to":"dev29.out0"},
    {"from":"dev12.in0","to":"dev30.out0"},
    {"from":"dev12.in1","to":"dev11.out0"},
    {"from":"dev12.in2","to":"dev21.out0"},
    {"from":"dev13.in0","to":"dev7.out0"},
    {"from":"dev14.in0","to":"dev1.out0"},
    {"from":"dev15.in0","to":"dev3.out0"},
    {"from":"dev16.in0","to":"dev0.out0"},
    {"from":"dev17.in0","to":"dev3.out0"},
    {"from":"dev18.in0","to":"dev11.out0"},
    {"from":"dev19.in0","to":"dev22.out0"},
    {"from":"dev20.in0","to":"dev17.out0"},
    {"from":"dev21.in0","to":"dev32.out0"},
    {"from":"dev22.in0","to":"dev14.out0"},
    {"from":"dev23.in0","to":"dev10.out0"},
    {"from":"dev24.in0","to":"dev4.out0"},
    {"from":"dev25.in0","to":"dev16.out0"},
    {"from":"dev26.in0","to":"dev27.out0"},
    {"from":"dev27.in0","to":"dev28.out0"},
    {"from":"dev28.in0","to":"dev17.out0"},
    {"from":"dev29.in0","to":"dev25.out0"},
    {"from":"dev30.in0","to":"dev31.out0"},
    {"from":"dev31.in0","to":"dev23.out0"},
    {"from":"dev32.in0","to":"dev24.out0"},
    {"from":"dev33.in0","to":"dev3.out0"}
  ]
}
);
